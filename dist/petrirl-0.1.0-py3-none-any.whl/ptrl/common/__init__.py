from ptrl.common.instance_loader import InstanceLoader
from ptrl.common.build_blocks import  Token,Place,Transition


